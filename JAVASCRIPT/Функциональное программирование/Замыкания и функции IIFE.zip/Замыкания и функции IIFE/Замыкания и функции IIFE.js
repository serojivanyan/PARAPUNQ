// 1.grel funkcia vory amen angam kancheluc berum e 1,2,3... (zamikaniaov)








// 2.unenq funkcia ,funkciai kanchi jamanak talis enq mek argument,argumenty pahum e ir local popoxakanum,
// erkrord kanchi jamanak talis enq urish argument mez veradarcnum e naxord argumenti ev tvatci gumary










// 3.grel funkcia vory amen angam kancheluc berum e 1,4,9,16,25,36,49,64,81.(zamikania)











// 4.unenq  funkcia zamikaniya mijocov petq e amen kanchi jamanak stexci mek button ok anunov gumarelov count@;
// count@ sksum a mekic









// 5.funkcian stanum e erku parametr;erkusn el petq e linen zangvatc;
// funkcian ashxatacneluc petq e veradarcni te vor zangvatc mej qani hat number ka















