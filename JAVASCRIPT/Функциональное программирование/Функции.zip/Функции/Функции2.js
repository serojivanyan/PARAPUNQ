// 1.grel mi funkcia vory arajin angam kancheluc alert e anum "hi", 2rd angam kancheluc "bye".










// 2.unenq funkcia vory stanum e 3 parametr ev hashvum e ayd parametreri artadryaly.
// xndir@ lucum enq erku exanakov mek@ ereq hat parametrov, myus tarberak@ ashxatum enq arguments zangvatcov











// 3.grel funkcia vory stanum e parametr ev hashvum e te qani tvanshanic e baxkacac parametry












// 4.grel funkcia vory hashvum e tvi tvanshanneri gumary












// 5.grel funkcia vory hashvum e tvi faktorialy













// 6.hashvel trvac tvi trvac astichany.(pow(5,3) petk e veradardzni 5i xoranard)













// 7.grel funkcia vory stugum e te tivy parz e te voch.