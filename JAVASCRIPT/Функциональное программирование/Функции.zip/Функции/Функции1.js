// 1.Unenq funkcia satnum e erku parametr,consolum tpel ayd erku parametreri gumary;










// 2.unenq funkcia stanum e parmaetr zangvatc,consolum tpel ayd zangvatci bolor andamnery ciklov












// 3.unenq funckia stanum e parametr zangvatc  mez veradarcnum e zangvatci max arjeqy












// 4.uneqn funkcai stanume 3 parametr mez veradarcnum e arajin parametr  gumaratc erkrord parametr bajanac errordi var










// 5.unenq funckia stanume parametr, voronc arjeqnery petq e linen string ev gumarum e ayd erku stringy












// 6.unenq funckia vor stanum e parametr;
// mecatcnum e ayd parametry 1-ov,talis mek ayl funkcaiyi vory bajanum e ayd veradarcnum






