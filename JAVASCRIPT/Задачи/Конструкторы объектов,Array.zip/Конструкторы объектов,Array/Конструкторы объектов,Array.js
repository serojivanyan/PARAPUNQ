/* unenq constructor funkcianer Hospital,Worker,Patients,Doctors

workers @ stanuma name, lastname, age,role - "role vorpes masnagitutyun"

dosctors @ stanuma name, lastname, age,role - "role vorpes masnagitutyun"

patients @ stanuma name, lastname, age, experience "experience inchqan jamankava hivanda,qani ora parkatc;stanuma tiv vorpes"  

hospital@ stanuma parametrer name u address,uni svoistvaner doctors, workers, patients
 voronq bolor@ datark zangvatcner en
 uni prototypeov avelacratc  methodner addDoctors,addPatients,addWorkers voronq stanum en objectner 
 (" orinak armenWorker object@ vor sarqvum a Worker constructor funkciayic,tenc doctorneri u patientneri hamar")

 bolor constructorner@ ashxatacneluc heto kanchum enq hosptali methodner@ u amen angam ira zangvatci mej enq qcum
 amen objecti anun@ +role, patientneri hamar el anun+ experinece
 orinak 
 malayan object@ piti lini es tesqi
  malayan = {
  	name:"Malayan",
  	address:"Erebuni 4/12",
  	doctors:["Armen - Terapeft"],
  	workers:["Ashot - Pahak"],
  	patient:["35or"]
 } */