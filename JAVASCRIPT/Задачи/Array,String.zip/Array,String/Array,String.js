//1. Даны два массива: ['a', 'b', 'c'] и [1, 2, 3]. Объедините их вместе.








//2Дан массив ['a', 'b', 'c']. Добавьте ему в конец элементы 1, 2, 3.








//3.Дана строка, например, '123456'. Переверните эту строку (сделайте из нее '654321') не используя цикл.











/* 4.unenq zangvatc arr = [1,3,6,"hello",-45,56,-3,"World",78,"Javascript"];
stanal erku zangvatc meki mej miayn stringner;myusi mej miayn numberner,
number zangvatci mej petq e linen mmiayn drakan tver;ev dasvorvat linen ajman kargov;
string zangvatci mej dasakargel nvazman kargov, stringn el ir hertin tareri hertakanutyun@ poxel orinak "hello"="olleh" */











/* 5.grel funkcia vor stanum e erku parametr mek@ zangvatc,myus@ number;veradarcnum e mez zangvatc vori andamner@
mec en nshvatc numberic;daskargvatc nvazman kargov*/












/*6.grel funkcia vor stanum  vor stanum e parametrer arr,cankacatc qanaki,
arajin arr-i amenamec erkarutyun unecox stringi lengthov katarum e filtracia;
bolor paymanin bavararox andamner@ qcum e mi zangvatci mej  xndir@ lucum enq
erku exanakov push() ev concat() methodnerov*/












/* 7.grel funkcia vor stanum e 2 parametr arr,stugum e erku 
zangvatci mej krknvox barer@ heracnum e ev veradarcnum  e 
mez erku zangvatvcn el;chkrknvox andamnerov */















/*8.grel funkcia vor@ stanum e parametr 2 zangvatc stugum e 
ardyoq bolor andamnern en 2 ev 3 i bazmapatikner;
bolor andamner@ qcum e mi zangvatci mej u veradarcnum zangvatc@*/























