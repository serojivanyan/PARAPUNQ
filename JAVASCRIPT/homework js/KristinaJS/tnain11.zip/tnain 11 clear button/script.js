function f(){
	  var a = document.getElementById('inp');
      a.value = a.value.slice(a.length, -1); 
      
      
}