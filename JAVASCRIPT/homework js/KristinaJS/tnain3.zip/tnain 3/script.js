/*var arr=[25,40,50,60,70];
var arr2=[15,1,5,16,8,45];
var arr3=[ ];
for(var i=0;i<=arr.length;i++){
	if(arr[i]%2==0){
 arr3.push(arr[i]) 
}
}


for(var i=0;i<=arr.length;i++){
	if(arr2[i]%2==1){
arr3.push(arr2[i])	
		
	
}
}

alert(arr3)*/


var arr0=[12,34,56,78];
var arr1=[ ];

for(i=arr0.length-1;i>=0;i--){
	arr1.push(arr0[i]);
}

document.write(arr1)