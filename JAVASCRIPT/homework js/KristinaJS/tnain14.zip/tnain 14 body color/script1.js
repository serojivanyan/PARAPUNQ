var d1=document.getElementById('d')

function f(){
	
	var r = document.getElementById("red").value
	var g = document.getElementById("green").value
	var b = document.getElementById("blue").value
    
    d1.style.backgroundColor="rgb("+r+","+g+","+b+")"	
    

}