// 1.unenq popoxakan var income = 300

// switch -i mijocov stugel 
// ete arjeq 100 consolum tpel "Доход равен 100" 
// ete arjeq 200 consolum tpel "Доход равен 200" 
// ete arjeq 300 consolum tpel "Доход равен 300" 
// ete urish arjeq e  consolum tpel "Доход неизвестной величины"










// 2.unenq  erku prompt, hamematuma erku tver@,mez veradardznum a ,min u max



















// 3.user@ nermucum e tiv stugum enq katarum ete tiv@ bajanvum e 2 consolum tpum enq tiv@ bajanvum e 2 i;ete chi bajanvum tpum enq 
// tiv@ chi bajanvum 2-i


















// 4.uneqn ereq hat propmt,voric erkus@ stanum en tiv;errord hanrahashvakan gorcoxutyan symbhol (+,-,*,/);
// ev @st nshvatc symbhol -i katarum e tvyal gorcoxutyun@
// orinak tvel enq 6 heto 2 heto / apa consolum petq e tpvi 3 















// 5.unenq tarva amisner@ 1-12,user@ nermucum e tiv ,consolum tpum enq te vor exanakn e
// orinak ete nermucel enq 7



















// 6.unenq erku popoxakanner userName ev passWord voronc arjeqnener@ hamapatsxanabar "ikoko2017@gmail.com","qwerty123" 
// promptov harcum enq katarum vortex petq e user@ nermuci login heto el password,stugum enq katarelu mer 
// popoxakaneri arjeqneri het
// ete erkusn el jisht e nermucvatc consolum tpum enq //"You are logged in as username" gumaratc userName
// ete sxal e nermucatc password@ tpum enq //"incorect password"
// ete sxal e username tpum enq //"you are not logged"



















// 7.Введите 2 числа , проверьте какое из них большее. Умножайте большее на 2, а к меньшему добавляйте большее.
//   Выведите информацию на экран.


















// 8. Введите 2 числа проверьте какое из чисел ближе к 10, при одинаковом “значении” определите слева или 
//    справа находятся числа. Проверьте на парах чисел.















// 9. В первом подъезде номера квартир от 1 до 20, во втором от 21 до 64,  в третьем от 65 до 80. Пользователь 
//    вводит номер квартиры, необходимо указать в каком она подъезде.


















// 10.unenq 3 hat zangac vortex grvac e 3 lezunerov shabatva orery..promptum grel arm beri hayerenov , 
//   ru ruseren, en angleren.



















  
// 11. unenq 3 prompt vorum grum enq ereq tiv voronq hamapatasxanum en erankyan koxmeri, stugum enq te trvac erankyuny 
// butankyun e, surankyun e,uxix e te goyutyun chuni.  